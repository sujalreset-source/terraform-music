import {
  MediaConvertClient,
  CreateJobCommand,
  DescribeEndpointsCommand,
} from "@aws-sdk/client-mediaconvert";

const REGION = "ap-south-1";
const BUCKET = process.env.DATA_BUCKET || "reset-streaming";
const OUTPUT_PREFIX = "songs-hls";

let mediaConvertEndpoint; // cached endpoint

export const handler = async (event) => {
  console.log("📨 Received SQS event:", JSON.stringify(event, null, 2));

  for (const record of event.Records || []) {
    const { bucket, key } = JSON.parse(record.body);

    console.log(`🎧 Starting MediaConvert job for: s3://${bucket}/${key}`);

    // 1️⃣ Describe endpoints (once)
    if (!mediaConvertEndpoint) {
      const describeClient = new MediaConvertClient({ region: REGION });
      const describe = await describeClient.send(new DescribeEndpointsCommand({}));
      mediaConvertEndpoint = describe.Endpoints[0].Url;
      console.log("🔗 MediaConvert endpoint:", mediaConvertEndpoint);
    }

    // 2️⃣ Build client
    const mcClient = new MediaConvertClient({
      region: REGION,
      endpoint: mediaConvertEndpoint,
    });

    // 3️⃣ Prepare job payload
    const outputKey = key
      .replace("songs/", `${OUTPUT_PREFIX}/`)
      .replace(/\.[^/.]+$/, "");

    const jobParams = {
      Role: process.env.MEDIACONVERT_ROLE_ARN,
      StatusUpdateInterval: "SECONDS_60",
      StatusUpdateTopic:
        "arn:aws:sns:ap-south-1:377905547433:mediaconvert-job-complete",
      UserMetadata: {
        inputFile: `s3://${bucket}/${key}`, // 👈 for EventBridge or SNS
      },
      Settings: {
        OutputGroups: [
          {
            Name: "HLS Group",
            OutputGroupSettings: {
              Type: "HLS_GROUP_SETTINGS",
              HlsGroupSettings: {
                SegmentLength: 5,
                MinSegmentLength: 2,
                Destination: `s3://${BUCKET}/${outputKey}/`,
              },
            },
            Outputs: [
              {
                NameModifier: "_hls",
                ContainerSettings: { Container: "M3U8", M3u8Settings: {} },
                AudioDescriptions: [
                  {
                    CodecSettings: {
                      Codec: "AAC",
                      AacSettings: {
                        Bitrate: 96000,
                        CodingMode: "CODING_MODE_2_0",
                        SampleRate: 48000,
                      },
                    },
                  },
                ],
              },
            ],
          },
        ],
        Inputs: [
          {
            FileInput: `s3://${bucket}/${key}`,
            AudioSelectors: { "Audio Selector 1": { DefaultSelection: "DEFAULT" } },
          },
        ],
      },
    };

    // 🔎 DEBUG: log the exact payload
    console.log("🔎 MediaConvert job payload:", JSON.stringify(jobParams, null, 2));

    // 4️⃣ Submit the job
    try {
      const { Job } = await mcClient.send(new CreateJobCommand(jobParams));
      console.log("✅ MediaConvert job submitted, ID:", Job.Id);
    } catch (err) {
      console.error("❌ MediaConvert submission failed:", JSON.stringify(err, null, 2));
    }
  }

  return { statusCode: 200 };
};





