import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";

const sqs = new SQSClient({ region: "ap-south-1" });
const QUEUE_URL = process.env.SQS_QUEUE_URL;
const allowedExtensions = [".mp3", ".wav"];

export const handler = async (event) => {
  console.log("📥 Received S3 event:", JSON.stringify(event, null, 2));

  for (const record of event.Records || []) {
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
    console.log(`🔍 Processing key: ${key}`);

    const ext = key.slice(key.lastIndexOf(".")).toLowerCase();
    if (!allowedExtensions.includes(ext)) {
      console.log(`⏭ Skipped unsupported file: ${key}`);
      continue;
    }

    const message = {
      bucket,
      key,
      uploadedAt: new Date().toISOString(),
    };

    console.log("📦 Sending message to SQS:", message);

    const command = new SendMessageCommand({
      QueueUrl: QUEUE_URL,
      MessageBody: JSON.stringify(message),
    });

    await sqs.send(command);
    console.log("✅ Message sent to SQS");
  }

  return { statusCode: 200 };
};

