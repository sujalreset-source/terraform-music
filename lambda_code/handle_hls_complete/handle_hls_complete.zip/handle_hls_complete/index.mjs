import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { MongoClient } from "mongodb";

const secretsClient = new SecretsManagerClient({ region: "ap-south-1" });

async function getMongoURI() {
  const command = new GetSecretValueCommand({
    SecretId: "reset/mongodb/uri",
  });
  const response = await secretsClient.send(command);
  const secret = JSON.parse(response.SecretString);
  return secret.MONGODB_URI;
}

export const handler = async (event) => {
  try {
    console.log("📥 Received EventBridge event:", JSON.stringify(event, null, 2));

    const { status, jobId, userMetadata, outputGroupDetails } = event.detail;
    const inputFile = userMetadata.inputFile;

    if (!inputFile) {
      console.error("❌ inputFile is undefined. Full detail:", event.detail);
      return;
    }

    if (status !== "COMPLETE") {
      console.log("⚠️ Job not complete, skipping...");
      return;
    }

    const inputKey = inputFile.split("/").pop().replace(/\.[^/.]+$/, ""); // e.g., song-key

    // Convert S3 URI to public HTTPS URl
    const rawS3Path = outputGroupDetails[0].outputDetails[0].outputFilePaths[0]; // s3://bucket/key
    const outputPath = rawS3Path
      .replace("s3://", "https://")
      .replace("reset-streaming", "reset-streaming.s3.ap-south-1.amazonaws.com");

    const mongoUri = await getMongoURI();
    const client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db("musicreset"); // change if needed
    const songs = db.collection("songs");

    const song2 = await songs.findOne({ audioKey: { $regex: inputKey } });
    console.log("📖 Found song:", song2);

    const updateResult = await songs.updateOne(
      { audioKey: { $regex: inputKey } },
      {
        $set: {
          hlsUrl: outputPath,
          hlsReady: true,
        },
      }
    );
    console.log("🧩 Connecting to Mongo URI:", mongoUri);


    console.log("✅ MongoDB update result:", updateResult);
    await client.close();
  } catch (err) {
    console.error("❌ error in handleHLSComplete Lambda:", err);
  }
};
